import React from 'react'
import './index.css'

const HistoryItem = props => {
  const {historyDetails, onDeleteHistoryItem} = props
  const {id, timeAccessed, logoUrl, title, domainUrl} = historyDetails

  const onDelete = () => {
    onDeleteHistoryItem(id)
  }

  return (
    <li className="history-item">
      <div className="item-details">
        <p>{timeAccessed}</p>
        <img src={logoUrl} alt="domain logo" />
        <div>
          <p>{title}</p>
          <p>{domainUrl}</p>
        </div>
      </div>
      <button onClick={onDelete} data-testid="delete">
        <img src="https://assets.ccbp.in/frontend/react-js/delete-img.png" alt="delete" />
      </button>
    </li>
  )
}

export default HistoryItem
