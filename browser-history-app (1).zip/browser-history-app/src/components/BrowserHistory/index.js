import React from 'react'
import HistoryItem from '../HistoryItem'
import './index.css'

const BrowserHistory = props => {
  const {historyDetailsList, onDeleteHistoryItem} = props

  return (
    <ul className="history-list">
      {historyDetailsList.map(eachItem => (
        <HistoryItem
          key={eachItem.id}
          historyDetails={eachItem}
          onDeleteHistoryItem={onDeleteHistoryItem}
        />
      ))}
    </ul>
  )
}

export default BrowserHistory
