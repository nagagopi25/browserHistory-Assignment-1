import React, {useState} from 'react'
import BrowserHistory from './components/BrowserHistory'
import './App.css'

const initialHistoryList = [
  {
    id: 0,
    timeAccessed: '07:45 PM',
    logoUrl: 'https://assets.ccbp.in/frontend/react-js/instagram-img.png',
    title: 'Instagram',
    domainUrl: 'instagram.com',
  },
  {
    id: 1,
    timeAccessed: '05:45 PM',
    logoUrl: 'https://assets.ccbp.in/frontend/react-js/twitter-img.png',
    title: 'Twitter',
    domainUrl: 'twitter.com',
  },
]

const App = () => {
  const [searchInput, setSearchInput] = useState('')
  const [historyList, setHistoryList] = useState(initialHistoryList)

  const onDeleteHistoryItem = id => {
    const updatedList = historyList.filter(item => item.id !== id)
    setHistoryList(updatedList)
  }

  const filteredHistory = historyList.filter(each =>
    each.title.toLowerCase().includes(searchInput.toLowerCase())
  )

  return (
    <div className="app-container">
      <div className="app-header">
        <img
          src="https://assets.ccbp.in/frontend/react-js/history-website-logo-img.png"
          alt="app logo"
        />
        <input
          type="search"
          value={searchInput}
          placeholder="Search history"
          onChange={e => setSearchInput(e.target.value)}
        />
      </div>
      <div className="history-container">
        {filteredHistory.length > 0 ? (
          <BrowserHistory
            historyDetailsList={filteredHistory}
            onDeleteHistoryItem={onDeleteHistoryItem}
          />
        ) : (
          <p>There is no history to show</p>
        )}
      </div>
    </div>
  )
}

export default App
